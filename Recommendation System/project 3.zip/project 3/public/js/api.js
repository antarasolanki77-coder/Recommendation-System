/* ============================================================
   Lumière — Shared API Helper, Toast System & Navbar
   ============================================================ */

// ─── API Module ───────────────────────────────────────────────
const API = {
  baseUrl: '',

  getToken() {
    return localStorage.getItem('token');
  },

  getUser() {
    const u = localStorage.getItem('user');
    return u ? JSON.parse(u) : null;
  },

  setAuth(data) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data));
  },

  clearAuth() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  isLoggedIn() {
    return !!this.getToken();
  },

  isAdmin() {
    const u = this.getUser();
    return u && u.role === 'admin';
  },

  async request(endpoint, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    const token = this.getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    try {
      const res = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Request failed');
      return data;
    } catch (error) {
      throw error;
    }
  },

  get(endpoint) {
    return this.request(endpoint);
  },

  post(endpoint, body) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    });
  },

  put(endpoint, body) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body),
    });
  },

  delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  },
};


// ─── Toast Notification System ────────────────────────────────
const Toast = {
  show(message, type = 'info') {
    const container =
      document.getElementById('toast-container') || this.createContainer();
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div class="toast-icon">${this._icon(type)}</div>
      <span class="toast-message">${message}</span>
      <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    container.appendChild(toast);

    // Auto‑dismiss after 3 s
    setTimeout(() => {
      toast.classList.add('toast-exit');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  },

  createContainer() {
    const c = document.createElement('div');
    c.id = 'toast-container';
    c.className = 'toast-container';
    document.body.appendChild(c);
    return c;
  },

  _icon(type) {
    const icons = {
      success: '✓',
      error: '✕',
      info: 'ℹ',
      warning: '⚠',
    };
    return icons[type] || icons.info;
  },

  success(msg) {
    this.show(msg, 'success');
  },
  error(msg) {
    this.show(msg, 'error');
  },
  info(msg) {
    this.show(msg, 'info');
  },
  warning(msg) {
    this.show(msg, 'warning');
  },
};


// ─── Dynamic Navbar ───────────────────────────────────────────
function initNavbar() {
  const nav = document.getElementById('navbar');
  if (!nav) return;

  const user = API.getUser();
  const isAdmin = API.isAdmin();

  nav.className = 'navbar';
  nav.innerHTML = `
    <div class="nav-container">
      <a href="/" class="nav-logo">
        <span class="nav-logo-icon">💎</span>
        <span class="nav-logo-text">Lumière</span>
      </a>

      <button class="nav-toggle" id="nav-toggle" aria-label="Toggle navigation menu">
        <span class="hamburger-line"></span>
        <span class="hamburger-line"></span>
        <span class="hamburger-line"></span>
      </button>

      <div class="nav-links" id="nav-links">
        <a href="/" class="nav-link">Home</a>
        <a href="/preferences.html" class="nav-link">Recommendations</a>
        ${user ? `<a href="/saved.html" class="nav-link">Saved</a>` : ''}
        ${isAdmin ? `<a href="/admin.html" class="nav-link">Admin</a>` : ''}
        ${
          user
            ? `
          <a href="/profile.html" class="nav-link nav-link-profile">
            <span class="nav-avatar">${(user.name || user.email || 'U').charAt(0).toUpperCase()}</span>
            Profile
          </a>
          <button class="btn-outline nav-btn" id="logout-btn">Logout</button>
        `
            : `
          <a href="/login.html" class="btn-primary nav-btn">Login</a>
          <a href="/register.html" class="btn-outline nav-btn">Register</a>
        `
        }
        <button class="theme-toggle" id="theme-toggle" title="Toggle theme">🌙</button>
      </div>
    </div>
  `;

  // ── Mobile hamburger toggle ──
  const toggle = document.getElementById('nav-toggle');
  const links = document.getElementById('nav-links');

  if (toggle && links) {
    toggle.addEventListener('click', () => {
      links.classList.toggle('nav-open');
      toggle.classList.toggle('nav-toggle-active');
    });

    // Close mobile menu when a link is clicked
    links.querySelectorAll('.nav-link, .nav-btn').forEach((el) => {
      el.addEventListener('click', () => {
        links.classList.remove('nav-open');
        toggle.classList.remove('nav-toggle-active');
      });
    });
  }

  // ── Logout handler ──
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      API.clearAuth();
      Toast.success('Logged out successfully');
      setTimeout(() => {
        window.location.href = '/login.html';
      }, 500);
    });
  }

  // ── Highlight active nav link ──
  const current = window.location.pathname;
  nav.querySelectorAll('.nav-link').forEach((link) => {
    const href = link.getAttribute('href');
    if (href === current || (href === '/' && current === '/index.html')) {
      link.classList.add('active');
    }
  });

  // ── Shrink navbar on scroll ──
  let lastScroll = 0;
  window.addEventListener(
    'scroll',
    () => {
      const scrollY = window.scrollY;
      if (scrollY > 60) {
        nav.classList.add('navbar-scrolled');
      } else {
        nav.classList.remove('navbar-scrolled');
      }
      if (scrollY > lastScroll && scrollY > 300) {
        nav.classList.add('navbar-hidden');
      } else {
        nav.classList.remove('navbar-hidden');
      }
      lastScroll = scrollY;
    },
    { passive: true }
  );
}

// ── Auth guard helper (used by other modules) ──
function requireAuth(redirectUrl = '/login.html') {
  if (!API.isLoggedIn()) {
    Toast.info('Please log in to continue');
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, 600);
    return false;
  }
  return true;
}

function requireAdmin(redirectUrl = '/') {
  if (!requireAuth()) return false;
  if (!API.isAdmin()) {
    Toast.error('Admin access required');
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, 600);
    return false;
  }
  return true;
}

// ── Kick off navbar on every page ──
document.addEventListener('DOMContentLoaded', initNavbar);
