/* ============================================================
   Lumière — Recommendation Results Page
   Displays AI‑curated jewelry recommendations
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  const resultsGrid = document.getElementById('results-grid');
  const resultsSummary = document.querySelector('.results-summary');
  const resultsCount = document.getElementById('results-count');
  const tryAgainBtn = document.getElementById('try-again-btn');
  const shareBtn = document.getElementById('share-btn');

  // ── Load results from sessionStorage ───────────────────────
  const raw = sessionStorage.getItem('recommendationResults');
  const prefRaw = sessionStorage.getItem('recommendationPreferences');

  if (!raw) {
    Toast.info('No recommendations found. Let\'s start fresh!');
    setTimeout(() => {
      window.location.href = '/preferences.html';
    }, 800);
    return;
  }

  let results;
  let preferences;

  try {
    const data = JSON.parse(raw);
    results = data.recommendations || data.results || data || [];
    preferences = prefRaw ? JSON.parse(prefRaw) : {};
  } catch (e) {
    console.error('Failed to parse results:', e);
    window.location.href = '/preferences.html';
    return;
  }

  if (!Array.isArray(results) || results.length === 0) {
    showEmptyResults();
    return;
  }

  // ── Render preference summary pills ────────────────────────
  renderSummary(preferences);

  // ── Render result count ────────────────────────────────────
  if (resultsCount) {
    resultsCount.textContent = `${results.length} recommendation${results.length !== 1 ? 's' : ''} found`;
  }

  // ── Render result cards ────────────────────────────────────
  renderResults(results);

  // ── Try Again button ───────────────────────────────────────
  if (tryAgainBtn) {
    tryAgainBtn.addEventListener('click', () => {
      sessionStorage.removeItem('recommendationResults');
      sessionStorage.removeItem('recommendationPreferences');
      window.location.href = '/preferences.html';
    });
  }

  // ── Share button ───────────────────────────────────────────
  if (shareBtn) {
    shareBtn.addEventListener('click', () => shareResults(results, preferences));
  }


  // ═════════════════════════════════════════════════════════════
  // RENDER FUNCTIONS
  // ═════════════════════════════════════════════════════════════

  function renderSummary(prefs) {
    if (!resultsSummary || !prefs) return;

    const labels = {
      occasion: 'Occasion',
      category: 'Category',
      metal: 'Metal',
      budgetRange: 'Budget',
      style: 'Style',
      color: 'Color',
    };

    const pills = Object.entries(prefs)
      .filter(([_, v]) => v)
      .map(
        ([key, value]) => `
        <span class="summary-pill">
          <span class="pill-label">${labels[key] || key}:</span>
          <span class="pill-value">${value}</span>
        </span>
      `
      )
      .join('');

    resultsSummary.innerHTML = `
      <h3 class="summary-title">Your Preferences</h3>
      <div class="summary-pills">${pills}</div>
    `;
  }

  function renderResults(items) {
    if (!resultsGrid) return;

    resultsGrid.innerHTML = items
      .map(
        (item, i) => `
      <div class="result-card animate-fadeInUp" style="animation-delay: ${i * 0.1}s" data-id="${item._id || i}">
        <div class="result-card-image">
          <img
            src="${item.image || ''}"
            alt="${escapeHtml(item.title || 'Jewelry')}"
            loading="lazy"
            onerror="this.src='https://images.unsplash.com/photo-1515562141589-67f0d569b3b3?w=400&h=400&fit=crop'"
          >
          <div class="match-badge ${getMatchClass(item.matchPercent)}">
            <svg class="match-circle" viewBox="0 0 36 36">
              <path
                class="match-circle-bg"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                class="match-circle-fill"
                stroke-dasharray="${item.matchPercent || 0}, 100"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <span class="match-text">${item.matchPercent || 0}%</span>
          </div>
        </div>
        <div class="result-card-body">
          <h3 class="result-title">${escapeHtml(item.title || 'Untitled')}</h3>
          <p class="result-price">₹${formatPrice(item.price)}</p>
          <p class="result-meta">
            ${escapeHtml(item.category || '')}${item.metal ? ' · ' + escapeHtml(item.metal) : ''}${item.style ? ' · ' + escapeHtml(item.style) : ''}
          </p>
          ${item.description ? `<p class="result-description">${escapeHtml(item.description)}</p>` : ''}
          <div class="result-reasons">
            ${(item.reasons || []).map((r) => `<span class="reason-tag">${escapeHtml(r)}</span>`).join('')}
          </div>
          <div class="result-card-actions">
            <button class="btn-primary save-btn" data-id="${item._id || ''}" data-saved="false">
              <span class="save-icon">♡</span> Save
            </button>
          </div>
        </div>
      </div>
    `
      )
      .join('');

    // ── Bind save buttons ──
    resultsGrid.querySelectorAll('.save-btn').forEach((btn) => {
      btn.addEventListener('click', () => handleSave(btn));
    });
  }

  function showEmptyResults() {
    if (!resultsGrid) return;

    resultsGrid.innerHTML = `
      <div class="empty-results">
        <div class="empty-icon">💎</div>
        <h3>No recommendations found</h3>
        <p>We couldn't find pieces matching your preferences. Try adjusting your selections.</p>
        <a href="/preferences.html" class="btn-primary">Try Different Preferences</a>
      </div>
    `;
  }


  // ═════════════════════════════════════════════════════════════
  // SAVE FUNCTIONALITY
  // ═════════════════════════════════════════════════════════════
  async function handleSave(btn) {
    const id = btn.dataset.id;
    if (!id) return;

    if (!API.isLoggedIn()) {
      Toast.info('Please log in to save recommendations');
      return;
    }

    const isSaved = btn.dataset.saved === 'true';

    if (isSaved) {
      // Unsave
      try {
        await API.delete(`/api/saved/${id}`);
        btn.dataset.saved = 'false';
        btn.innerHTML = '<span class="save-icon">♡</span> Save';
        btn.classList.remove('saved');
        Toast.info('Removed from saved items');
      } catch (err) {
        Toast.error(err.message || 'Failed to remove');
      }
    } else {
      // Save
      try {
        await API.post(`/api/saved/${id}`);
        btn.dataset.saved = 'true';
        btn.innerHTML = '<span class="save-icon">♥</span> Saved';
        btn.classList.add('saved');

        // Celebration animation
        createSaveParticles(btn);
        Toast.success('Saved to your collection!');
      } catch (err) {
        Toast.error(err.message || 'Failed to save');
      }
    }
  }


  // ═════════════════════════════════════════════════════════════
  // SHARE FUNCTIONALITY
  // ═════════════════════════════════════════════════════════════
  async function shareResults(items, prefs) {
    const summary = buildShareText(items, prefs);

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Lumière Jewelry Recommendations',
          text: summary,
          url: window.location.href,
        });
        Toast.success('Shared successfully!');
      } catch (err) {
        if (err.name !== 'AbortError') {
          fallbackCopy(summary);
        }
      }
    } else {
      fallbackCopy(summary);
    }
  }

  function buildShareText(items, prefs) {
    let text = '✨ My Lumière Jewelry Recommendations ✨\n\n';

    if (prefs && Object.keys(prefs).length) {
      text += 'Preferences: ' + Object.values(prefs).filter(Boolean).join(', ') + '\n\n';
    }

    items.slice(0, 5).forEach((item, i) => {
      text += `${i + 1}. ${item.title} — ₹${formatPrice(item.price)} (${item.matchPercent}% match)\n`;
    });

    if (items.length > 5) {
      text += `\n... and ${items.length - 5} more\n`;
    }

    text += '\nDiscover yours at Lumière 💎';
    return text;
  }

  function fallbackCopy(text) {
    navigator.clipboard
      .writeText(text)
      .then(() => Toast.success('Copied to clipboard!'))
      .catch(() => Toast.error('Failed to copy'));
  }


  // ═════════════════════════════════════════════════════════════
  // UTILITIES
  // ═════════════════════════════════════════════════════════════

  function getMatchClass(percent) {
    if (percent >= 80) return 'high';
    if (percent >= 60) return 'medium';
    return 'low';
  }

  function formatPrice(price) {
    if (!price && price !== 0) return '—';
    return Number(price).toLocaleString('en-IN');
  }

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function createSaveParticles(btn) {
    const rect = btn.getBoundingClientRect();
    const particles = 8;

    for (let i = 0; i < particles; i++) {
      const particle = document.createElement('span');
      particle.className = 'save-particle';
      particle.textContent = '♥';
      particle.style.cssText = `
        position: fixed;
        left: ${rect.left + rect.width / 2}px;
        top: ${rect.top + rect.height / 2}px;
        pointer-events: none;
        font-size: 12px;
        color: var(--gold);
        z-index: 9999;
        animation: saveParticle 0.8s ease-out forwards;
        --angle: ${(360 / particles) * i}deg;
        --distance: ${30 + Math.random() * 20}px;
      `;
      document.body.appendChild(particle);
      setTimeout(() => particle.remove(), 800);
    }
  }
});
