/* ============================================================
   Lumière — Admin Panel
   Analytics · Product CRUD · Modal Management
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // ── Admin gate ─────────────────────────────────────────────
  if (!requireAdmin()) return;

  // ── DOM References ─────────────────────────────────────────
  const statsGrid = document.getElementById('stats-grid');
  const productTable = document.getElementById('product-table');
  const productTableBody = document.getElementById('product-table-body');
  const addProductBtn = document.getElementById('add-product-btn');
  const productModal = document.getElementById('product-modal');
  const productForm = document.getElementById('product-form');
  const modalTitle = document.getElementById('modal-title');
  const modalCloseBtn = document.querySelector('.modal-close');
  const modalCancelBtn = document.getElementById('modal-cancel-btn');
  const searchInput = document.getElementById('admin-search');
  const categoryFilter = document.getElementById('admin-category-filter');
  const refreshBtn = document.getElementById('refresh-btn');

  // ── State ──────────────────────────────────────────────────
  let products = [];
  let editingId = null;

  // ── Initialise ─────────────────────────────────────────────
  loadAnalytics();
  loadProducts();
  bindEvents();


  // ═════════════════════════════════════════════════════════════
  // EVENT BINDINGS
  // ═════════════════════════════════════════════════════════════
  function bindEvents() {
    // Add product
    if (addProductBtn) {
      addProductBtn.addEventListener('click', () => openModal());
    }

    // Form submit
    if (productForm) {
      productForm.addEventListener('submit', handleFormSubmit);
    }

    // Modal close
    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', closeModal);
    }
    if (modalCancelBtn) {
      modalCancelBtn.addEventListener('click', closeModal);
    }

    // Click outside modal to close
    if (productModal) {
      productModal.addEventListener('click', (e) => {
        if (e.target === productModal) closeModal();
      });
    }

    // Escape key to close modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });

    // Search
    if (searchInput) {
      let debounceTimer;
      searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => filterProducts(), 250);
      });
    }

    // Category filter
    if (categoryFilter) {
      categoryFilter.addEventListener('change', () => filterProducts());
    }

    // Refresh
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        loadAnalytics();
        loadProducts();
        Toast.info('Data refreshed');
      });
    }
  }


  // ═════════════════════════════════════════════════════════════
  // ANALYTICS
  // ═════════════════════════════════════════════════════════════
  async function loadAnalytics() {
    if (!statsGrid) return;

    // Show skeleton
    statsGrid.innerHTML = Array.from({ length: 4 })
      .map(
        () => `
      <div class="stat-card skeleton-card">
        <div class="skeleton-line skeleton-short"></div>
        <div class="skeleton-line skeleton-title"></div>
      </div>
    `
      )
      .join('');

    try {
      const data = await API.get('/api/products/analytics');

      const stats = [
        {
          label: 'Total Products',
          value: data.totalProducts || data.total || 0,
          icon: '💎',
          color: 'var(--gold)',
        },
        {
          label: 'Categories',
          value: data.categories || data.totalCategories || 0,
          icon: '📦',
          color: '#6366f1',
        },
        {
          label: 'Total Users',
          value: data.totalUsers || data.users || 0,
          icon: '👥',
          color: '#10b981',
        },
        {
          label: 'Recommendations',
          value: data.totalRecommendations || data.recommendations || 0,
          icon: '✨',
          color: '#f59e0b',
        },
      ];

      statsGrid.innerHTML = stats
        .map(
          (stat, i) => `
        <div class="stat-card animate-fadeInUp" style="animation-delay: ${i * 0.1}s">
          <div class="stat-icon" style="color: ${stat.color}">${stat.icon}</div>
          <div class="stat-info">
            <span class="stat-value" data-counter="${stat.value}">${stat.value.toLocaleString('en-IN')}</span>
            <span class="stat-label">${stat.label}</span>
          </div>
        </div>
      `
        )
        .join('');
    } catch (err) {
      statsGrid.innerHTML = `
        <div class="stat-card error-card">
          <p>Failed to load analytics</p>
        </div>
      `;
      console.error(err);
    }
  }


  // ═════════════════════════════════════════════════════════════
  // PRODUCTS TABLE
  // ═════════════════════════════════════════════════════════════
  async function loadProducts() {
    if (!productTableBody) return;

    productTableBody.innerHTML = `
      <tr>
        <td colspan="6" class="table-loading">
          <div class="btn-spinner"></div> Loading products...
        </td>
      </tr>
    `;

    try {
      const data = await API.get('/api/products');
      products = data.products || data || [];
      if (!Array.isArray(products)) products = [];

      populateAdminCategoryFilter(products);
      renderProducts(products);
    } catch (err) {
      productTableBody.innerHTML = `
        <tr>
          <td colspan="6" class="table-empty">Failed to load products. <button class="btn-link" onclick="location.reload()">Retry</button></td>
        </tr>
      `;
      Toast.error('Failed to load products');
      console.error(err);
    }
  }

  function renderProducts(items) {
    if (!productTableBody) return;

    if (items.length === 0) {
      productTableBody.innerHTML = `
        <tr>
          <td colspan="6" class="table-empty">
            No products found. Click "Add Product" to create one.
          </td>
        </tr>
      `;
      return;
    }

    productTableBody.innerHTML = items
      .map(
        (product, i) => `
      <tr class="product-row animate-fadeInUp" style="animation-delay: ${i * 0.03}s" data-id="${product._id || ''}">
        <td class="td-product">
          <div class="product-cell">
            <img
              class="product-thumb"
              src="${product.image || ''}"
              alt="${escapeHtml(product.title || '')}"
              onerror="this.src='https://images.unsplash.com/photo-1515562141589-67f0d569b3b3?w=60&h=60&fit=crop'"
            >
            <span class="product-name">${escapeHtml(product.title || 'Untitled')}</span>
          </div>
        </td>
        <td><span class="table-tag">${escapeHtml(product.category || '—')}</span></td>
        <td>${escapeHtml(product.occasion || '—')}</td>
        <td>${escapeHtml(product.metal || '—')}</td>
        <td class="td-price">₹${formatPrice(product.price)}</td>
        <td class="td-actions">
          <button class="btn-icon edit-btn" data-id="${product._id || ''}" title="Edit product">
            ✏️
          </button>
          <button class="btn-icon delete-btn" data-id="${product._id || ''}" title="Delete product">
            🗑️
          </button>
        </td>
      </tr>
    `
      )
      .join('');

    // Bind action buttons
    productTableBody.querySelectorAll('.edit-btn').forEach((btn) => {
      btn.addEventListener('click', () => handleEdit(btn.dataset.id));
    });

    productTableBody.querySelectorAll('.delete-btn').forEach((btn) => {
      btn.addEventListener('click', () => handleDelete(btn.dataset.id, btn));
    });
  }

  function filterProducts() {
    const search = searchInput ? searchInput.value.trim().toLowerCase() : '';
    const category = categoryFilter ? categoryFilter.value : '';

    const filtered = products.filter((p) => {
      const matchesSearch =
        !search ||
        (p.title || '').toLowerCase().includes(search) ||
        (p.category || '').toLowerCase().includes(search) ||
        (p.metal || '').toLowerCase().includes(search) ||
        (p.occasion || '').toLowerCase().includes(search);

      const matchesCategory = !category || (p.category || '').toLowerCase() === category.toLowerCase();

      return matchesSearch && matchesCategory;
    });

    renderProducts(filtered);
  }

  function populateAdminCategoryFilter(items) {
    if (!categoryFilter) return;
    const categories = [...new Set(items.map((i) => i.category).filter(Boolean))];
    categoryFilter.innerHTML =
      '<option value="">All Categories</option>' +
      categories.map((c) => `<option value="${c}">${c}</option>`).join('');
  }


  // ═════════════════════════════════════════════════════════════
  // MODAL MANAGEMENT
  // ═════════════════════════════════════════════════════════════
  function openModal(product = null) {
    if (!productModal || !productForm) return;

    editingId = product ? product._id : null;

    if (modalTitle) {
      modalTitle.textContent = product ? 'Edit Product' : 'Add New Product';
    }

    // Reset or populate form
    productForm.reset();

    if (product) {
      setFormField('product-title', product.title);
      setFormField('product-category', product.category);
      setFormField('product-occasion', product.occasion);
      setFormField('product-metal', product.metal);
      setFormField('product-style', product.style);
      setFormField('product-color', product.color);
      setFormField('product-price', product.price);
      setFormField('product-image', product.image);
      setFormField('product-description', product.description);
      setFormField('product-budget-range', product.budgetRange);
    }

    // Show modal
    productModal.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Focus first input
    setTimeout(() => {
      const firstInput = productForm.querySelector('input, select, textarea');
      if (firstInput) firstInput.focus();
    }, 200);
  }

  function closeModal() {
    if (!productModal) return;

    productModal.classList.remove('active');
    document.body.style.overflow = '';
    editingId = null;

    if (productForm) productForm.reset();
  }

  function setFormField(id, value) {
    const el = document.getElementById(id);
    if (el && value !== undefined && value !== null) {
      el.value = value;
    }
  }


  // ═════════════════════════════════════════════════════════════
  // FORM SUBMIT (ADD / EDIT)
  // ═════════════════════════════════════════════════════════════
  async function handleFormSubmit(e) {
    e.preventDefault();

    const submitBtn = productForm.querySelector('button[type="submit"]');
    const formData = getFormData();

    // Basic validation
    if (!formData.title || !formData.title.trim()) {
      Toast.error('Product title is required');
      return;
    }
    if (!formData.price || isNaN(formData.price) || formData.price <= 0) {
      Toast.error('Valid price is required');
      return;
    }

    setLoading(submitBtn, true);

    try {
      if (editingId) {
        // Update existing
        await API.put(`/api/products/${editingId}`, formData);
        Toast.success('Product updated successfully');
      } else {
        // Create new
        await API.post('/api/products', formData);
        Toast.success('Product added successfully');
      }

      closeModal();
      loadProducts();
      loadAnalytics();
    } catch (err) {
      Toast.error(err.message || 'Failed to save product');
    } finally {
      setLoading(submitBtn, false);
    }
  }

  function getFormData() {
    return {
      title: getFieldValue('product-title'),
      category: getFieldValue('product-category'),
      occasion: getFieldValue('product-occasion'),
      metal: getFieldValue('product-metal'),
      style: getFieldValue('product-style'),
      color: getFieldValue('product-color'),
      price: parseFloat(getFieldValue('product-price')) || 0,
      image: getFieldValue('product-image'),
      description: getFieldValue('product-description'),
      budgetRange: getFieldValue('product-budget-range'),
    };
  }

  function getFieldValue(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
  }


  // ═════════════════════════════════════════════════════════════
  // EDIT
  // ═════════════════════════════════════════════════════════════
  function handleEdit(id) {
    const product = products.find((p) => p._id === id);
    if (!product) {
      Toast.error('Product not found');
      return;
    }
    openModal(product);
  }


  // ═════════════════════════════════════════════════════════════
  // DELETE
  // ═════════════════════════════════════════════════════════════
  async function handleDelete(id, btn) {
    if (!id) return;

    const row = btn.closest('tr');

    // Two‑click confirmation
    if (btn.dataset.confirming === 'true') {
      btn.disabled = true;

      try {
        await API.delete(`/api/products/${id}`);

        // Animate row removal
        if (row) {
          row.style.transition = 'all 0.3s ease';
          row.style.opacity = '0';
          row.style.transform = 'translateX(40px)';

          setTimeout(() => {
            row.remove();
            products = products.filter((p) => p._id !== id);

            if (products.length === 0) {
              renderProducts([]);
            }
          }, 300);
        }

        Toast.success('Product deleted');
        loadAnalytics();
      } catch (err) {
        Toast.error(err.message || 'Failed to delete product');
        btn.disabled = false;
      }
    } else {
      // First click → ask for confirmation
      btn.dataset.confirming = 'true';
      btn.textContent = '⚠️';
      btn.title = 'Click again to confirm deletion';
      btn.classList.add('btn-danger');

      setTimeout(() => {
        if (btn.dataset.confirming === 'true') {
          btn.dataset.confirming = 'false';
          btn.textContent = '🗑️';
          btn.title = 'Delete product';
          btn.classList.remove('btn-danger');
        }
      }, 3000);
    }
  }


  // ═════════════════════════════════════════════════════════════
  // UTILITIES
  // ═════════════════════════════════════════════════════════════
  function formatPrice(price) {
    if (!price && price !== 0) return '—';
    return Number(price).toLocaleString('en-IN');
  }

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function setLoading(button, loading) {
    if (!button) return;
    if (loading) {
      button.dataset.originalText = button.textContent;
      button.disabled = true;
      button.innerHTML = '<span class="btn-spinner"></span> Saving...';
      button.classList.add('btn-loading');
    } else {
      button.disabled = false;
      button.textContent = button.dataset.originalText || 'Save';
      button.classList.remove('btn-loading');
    }
  }
});
