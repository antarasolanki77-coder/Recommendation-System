/* ============================================================
   Lumière — Home Page Interactivity
   Scroll Animations · Parallax · Counters
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  initScrollAnimations();
  initParallax();
  initCounters();
  initSmoothScroll();
  initHeroParticles();
});


// ═════════════════════════════════════════════════════════════
// SCROLL FADE‑IN ANIMATIONS (IntersectionObserver)
// ═════════════════════════════════════════════════════════════
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll(
    'section, .feature-card, .step-card, .testimonial-card, .cta-section, .stat-card, [data-animate]'
  );

  if (!animatedElements.length) return;

  // Add initial hidden state
  animatedElements.forEach((el) => {
    if (!el.classList.contains('no-animate')) {
      el.classList.add('animate-hidden');
    }
  });

  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -80px 0px',
    threshold: 0.1,
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const delay = el.dataset.animateDelay || 0;

        setTimeout(() => {
          el.classList.remove('animate-hidden');
          el.classList.add('animate-fadeInUp');
        }, delay);

        observer.unobserve(el);
      }
    });
  }, observerOptions);

  animatedElements.forEach((el) => observer.observe(el));
}


// ═════════════════════════════════════════════════════════════
// PARALLAX HERO EFFECT
// ═════════════════════════════════════════════════════════════
function initParallax() {
  const hero = document.querySelector('.hero-section');
  if (!hero) return;

  const heroContent = hero.querySelector('.hero-content');
  const heroImage = hero.querySelector('.hero-image, .hero-visual');

  window.addEventListener(
    'scroll',
    () => {
      const scrollY = window.scrollY;
      const heroHeight = hero.offsetHeight;

      if (scrollY > heroHeight) return; // Skip once past hero

      const factor = scrollY * 0.3;
      const opacity = 1 - scrollY / heroHeight;

      if (heroContent) {
        heroContent.style.transform = `translateY(${factor}px)`;
        heroContent.style.opacity = Math.max(opacity, 0);
      }
      if (heroImage) {
        heroImage.style.transform = `translateY(${factor * 0.5}px) scale(${1 + scrollY * 0.0003})`;
      }
    },
    { passive: true }
  );
}


// ═════════════════════════════════════════════════════════════
// ANIMATED COUNTERS
// ═════════════════════════════════════════════════════════════
function initCounters() {
  const counters = document.querySelectorAll('[data-counter]');
  if (!counters.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach((el) => observer.observe(el));
}

function animateCounter(el) {
  const target = parseInt(el.dataset.counter, 10);
  const suffix = el.dataset.counterSuffix || '';
  const duration = 2000;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);

    // Ease out cubic
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.round(target * eased);

    el.textContent = current.toLocaleString('en-IN') + suffix;

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}


// ═════════════════════════════════════════════════════════════
// SMOOTH SCROLL FOR ANCHOR LINKS
// ═════════════════════════════════════════════════════════════
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (targetId === '#') return;

      const targetEl = document.querySelector(targetId);
      if (!targetEl) return;

      e.preventDefault();
      targetEl.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    });
  });
}


// ═════════════════════════════════════════════════════════════
// HERO FLOATING PARTICLES (Decorative)
// ═════════════════════════════════════════════════════════════
function initHeroParticles() {
  const hero = document.querySelector('.hero-section');
  if (!hero) return;

  // Don't add particles on low‑performance devices
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const particleContainer = document.createElement('div');
  particleContainer.className = 'hero-particles';
  particleContainer.setAttribute('aria-hidden', 'true');
  hero.appendChild(particleContainer);

  const particleCount = 20;
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement('span');
    particle.className = 'hero-particle';
    particle.style.cssText = `
      left: ${Math.random() * 100}%;
      top: ${Math.random() * 100}%;
      width: ${2 + Math.random() * 4}px;
      height: ${2 + Math.random() * 4}px;
      animation-delay: ${Math.random() * 6}s;
      animation-duration: ${4 + Math.random() * 6}s;
      opacity: ${0.2 + Math.random() * 0.4};
    `;
    particleContainer.appendChild(particle);
  }
}
