/* ============================================================
   Lumière — Multi‑Step Preference Wizard
   6 Steps → AI Recommendation Engine
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  const wizard = document.getElementById('preference-wizard');
  if (!wizard) return;

  // ── State ──────────────────────────────────────────────────
  let currentStep = 0;
  const totalSteps = 6;
  const stepKeys = ['occasion', 'category', 'metal', 'budgetRange', 'style', 'color'];
  const preferences = {};

  // ── DOM References ─────────────────────────────────────────
  const steps = wizard.querySelectorAll('.wizard-step');
  const progressFill = wizard.querySelector('.progress-fill');
  const progressText = wizard.querySelector('.progress-text');
  const stepIndicators = wizard.querySelectorAll('.step-indicator');
  const prevBtn = wizard.querySelector('#prev-btn');
  const nextBtn = wizard.querySelector('#next-btn');
  const submitBtn = wizard.querySelector('#submit-btn');
  const loadingOverlay = document.getElementById('loading-overlay');

  // ── Initial Setup ──────────────────────────────────────────
  updateUI();
  bindOptionCards();
  bindNavButtons();


  // ═════════════════════════════════════════════════════════════
  // OPTION CARD SELECTION
  // ═════════════════════════════════════════════════════════════
  function bindOptionCards() {
    wizard.querySelectorAll('.option-card').forEach((card) => {
      card.addEventListener('click', () => {
        const step = card.closest('.wizard-step');
        const stepIndex = Array.from(steps).indexOf(step);
        const key = stepKeys[stepIndex];
        const value = card.dataset.value;

        // Remove selected from siblings
        step.querySelectorAll('.option-card').forEach((c) => c.classList.remove('selected'));

        // Select this card
        card.classList.add('selected');

        // Store preference
        preferences[key] = value;

        // Haptic‑style feedback animation
        card.classList.add('option-pulse');
        setTimeout(() => card.classList.remove('option-pulse'), 300);

        // Auto‑advance after a short delay (except last step)
        if (stepIndex < totalSteps - 1) {
          setTimeout(() => goToStep(currentStep + 1), 400);
        }
      });

      // Keyboard accessibility
      card.setAttribute('tabindex', '0');
      card.setAttribute('role', 'button');
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          card.click();
        }
      });
    });
  }


  // ═════════════════════════════════════════════════════════════
  // NAVIGATION
  // ═════════════════════════════════════════════════════════════
  function bindNavButtons() {
    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        if (currentStep > 0) goToStep(currentStep - 1);
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        if (validateCurrentStep()) {
          goToStep(currentStep + 1);
        }
      });
    }

    if (submitBtn) {
      submitBtn.addEventListener('click', () => {
        if (validateCurrentStep()) {
          submitPreferences();
        }
      });
    }

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' && currentStep < totalSteps - 1) {
        if (validateCurrentStep()) goToStep(currentStep + 1);
      }
      if (e.key === 'ArrowLeft' && currentStep > 0) {
        goToStep(currentStep - 1);
      }
    });
  }


  // ═════════════════════════════════════════════════════════════
  // STEP MANAGEMENT
  // ═════════════════════════════════════════════════════════════
  function goToStep(index) {
    if (index < 0 || index >= totalSteps) return;

    const direction = index > currentStep ? 'next' : 'prev';

    // Animate current step out
    const currentStepEl = steps[currentStep];
    if (currentStepEl) {
      currentStepEl.classList.add(direction === 'next' ? 'slide-out-left' : 'slide-out-right');
      setTimeout(() => {
        currentStepEl.classList.remove('active', 'slide-out-left', 'slide-out-right');
      }, 350);
    }

    // Animate new step in
    const nextStepEl = steps[index];
    if (nextStepEl) {
      setTimeout(() => {
        nextStepEl.classList.add(direction === 'next' ? 'slide-in-right' : 'slide-in-left');
        nextStepEl.classList.add('active');
        setTimeout(() => {
          nextStepEl.classList.remove('slide-in-right', 'slide-in-left');
        }, 350);
      }, 100);
    }

    currentStep = index;
    updateUI();
  }

  function validateCurrentStep() {
    const key = stepKeys[currentStep];
    if (!preferences[key]) {
      Toast.info('Please select an option to continue');
      // Shake the options grid
      const grid = steps[currentStep]?.querySelector('.options-grid');
      if (grid) {
        grid.classList.add('shake');
        setTimeout(() => grid.classList.remove('shake'), 600);
      }
      return false;
    }
    return true;
  }


  // ═════════════════════════════════════════════════════════════
  // UI UPDATES
  // ═════════════════════════════════════════════════════════════
  function updateUI() {
    // Progress bar
    const progress = ((currentStep + 1) / totalSteps) * 100;
    if (progressFill) {
      progressFill.style.width = `${progress}%`;
    }
    if (progressText) {
      progressText.textContent = `Step ${currentStep + 1} of ${totalSteps}`;
    }

    // Step indicators
    stepIndicators.forEach((indicator, i) => {
      indicator.classList.remove('active', 'completed');
      if (i < currentStep) {
        indicator.classList.add('completed');
      } else if (i === currentStep) {
        indicator.classList.add('active');
      }
    });

    // Nav buttons visibility
    if (prevBtn) {
      prevBtn.style.visibility = currentStep === 0 ? 'hidden' : 'visible';
    }
    if (nextBtn) {
      nextBtn.style.display = currentStep < totalSteps - 1 ? 'inline-flex' : 'none';
    }
    if (submitBtn) {
      submitBtn.style.display = currentStep === totalSteps - 1 ? 'inline-flex' : 'none';
    }

    // Ensure active step is shown (initial load)
    steps.forEach((step, i) => {
      if (i === currentStep) {
        step.classList.add('active');
      } else if (!step.classList.contains('slide-out-left') && !step.classList.contains('slide-out-right')) {
        step.classList.remove('active');
      }
    });
  }


  // ═════════════════════════════════════════════════════════════
  // SUBMIT PREFERENCES TO API
  // ═════════════════════════════════════════════════════════════
  async function submitPreferences() {
    // Auth check
    if (!API.isLoggedIn()) {
      Toast.info('Please log in to get personalised recommendations');
      sessionStorage.setItem('pendingPreferences', JSON.stringify(preferences));
      setTimeout(() => {
        window.location.href = '/login.html';
      }, 600);
      return;
    }

    // Validate all steps have selections
    for (let i = 0; i < totalSteps; i++) {
      if (!preferences[stepKeys[i]]) {
        Toast.error(`Please complete step ${i + 1}`);
        goToStep(i);
        return;
      }
    }

    // Show loading overlay
    showLoading(true);

    try {
      const data = await API.post('/api/recommendations', preferences);

      // Store results in sessionStorage
      sessionStorage.setItem('recommendationResults', JSON.stringify(data));
      sessionStorage.setItem('recommendationPreferences', JSON.stringify(preferences));

      Toast.success('Your recommendations are ready!');
      setTimeout(() => {
        window.location.href = '/results.html';
      }, 500);

    } catch (err) {
      Toast.error(err.message || 'Failed to get recommendations. Please try again.');
      console.error('Recommendation error:', err);
    } finally {
      showLoading(false);
    }
  }


  // ═════════════════════════════════════════════════════════════
  // LOADING OVERLAY
  // ═════════════════════════════════════════════════════════════
  function showLoading(show) {
    if (loadingOverlay) {
      if (show) {
        loadingOverlay.classList.add('active');
        loadingOverlay.innerHTML = `
          <div class="loading-content">
            <div class="loading-spinner">
              <div class="spinner-ring"></div>
              <span class="loading-icon">💎</span>
            </div>
            <h3 class="loading-title">Crafting Your Recommendations</h3>
            <p class="loading-subtitle">Our AI is finding the perfect pieces for you...</p>
            <div class="loading-dots">
              <span></span><span></span><span></span>
            </div>
          </div>
        `;
      } else {
        loadingOverlay.classList.remove('active');
      }
    }
  }

  // ── Restore pending preferences (if redirected from login) ─
  const pending = sessionStorage.getItem('pendingPreferences');
  if (pending && API.isLoggedIn()) {
    try {
      const restored = JSON.parse(pending);
      Object.assign(preferences, restored);
      sessionStorage.removeItem('pendingPreferences');

      // Re‑select option cards visually
      steps.forEach((step, i) => {
        const key = stepKeys[i];
        if (preferences[key]) {
          const card = step.querySelector(`.option-card[data-value="${preferences[key]}"]`);
          if (card) card.classList.add('selected');
        }
      });

      // Jump to last completed step
      const lastCompleted = stepKeys.findIndex((key) => !preferences[key]);
      if (lastCompleted > 0) goToStep(lastCompleted);
      else if (lastCompleted === -1) goToStep(totalSteps - 1);

      Toast.info('Your previous selections have been restored');
    } catch (e) {
      sessionStorage.removeItem('pendingPreferences');
    }
  }
});
