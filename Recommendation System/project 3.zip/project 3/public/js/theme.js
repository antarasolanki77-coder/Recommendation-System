/* ============================================================
   Lumière — Theme Toggle (Dark / Light Mode)
   ============================================================ */

(function () {
  'use strict';

  const STORAGE_KEY = 'theme';
  const DARK = 'dark';
  const LIGHT = 'light';
  const ICON_DARK = '🌙';
  const ICON_LIGHT = '☀️';

  // ── Resolve initial theme ──────────────────────────────────
  function getPreferredTheme() {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === DARK || stored === LIGHT) return stored;

    // Fall back to OS preference, default dark for luxury feel
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
      return LIGHT;
    }
    return DARK;
  }

  // ── Apply theme to the document ────────────────────────────
  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
    updateToggleButtons(theme);
  }

  // ── Update every toggle button icon on the page ────────────
  function updateToggleButtons(theme) {
    document.querySelectorAll('#theme-toggle, .theme-toggle').forEach((btn) => {
      btn.textContent = theme === DARK ? ICON_DARK : ICON_LIGHT;
      btn.setAttribute('aria-label', `Switch to ${theme === DARK ? 'light' : 'dark'} mode`);
      btn.title = `Switch to ${theme === DARK ? 'light' : 'dark'} mode`;
    });
  }

  // ── Toggle between dark & light ────────────────────────────
  function toggleTheme() {
    const current = document.documentElement.dataset.theme || DARK;
    const next = current === DARK ? LIGHT : DARK;
    applyTheme(next);
  }

  // ── Bind click listener (works even if button is injected later) ──
  function bindToggle() {
    document.addEventListener('click', (e) => {
      if (e.target.matches('#theme-toggle, .theme-toggle')) {
        e.preventDefault();
        toggleTheme();
      }
    });
  }

  // ── Listen for OS‑level preference changes ─────────────────
  function listenSystemChange() {
    if (!window.matchMedia) return;
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      // Only follow system if user hasn't explicitly chosen
      if (!localStorage.getItem(STORAGE_KEY)) {
        applyTheme(e.matches ? DARK : LIGHT);
      }
    });
  }

  // ── Initialise ─────────────────────────────────────────────
  // Apply immediately (before DOMContentLoaded) to prevent flash
  applyTheme(getPreferredTheme());
  bindToggle();
  listenSystemChange();

  // Once DOM is ready, update any buttons rendered by the navbar
  document.addEventListener('DOMContentLoaded', () => {
    updateToggleButtons(document.documentElement.dataset.theme || DARK);
  });

  // Expose for programmatic access
  window.ThemeManager = {
    toggle: toggleTheme,
    set: applyTheme,
    get: () => document.documentElement.dataset.theme || DARK,
  };
})();
