/* ============================================================
   Lumière — Authentication Module
   Login · Register · Profile
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // ── Detect current page by element IDs ─────────────────────
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const profileForm = document.getElementById('profile-form');

  if (loginForm) initLogin(loginForm);
  if (registerForm) initRegister(registerForm);
  if (profileForm) initProfile(profileForm);
});


// ═════════════════════════════════════════════════════════════
// LOGIN
// ═════════════════════════════════════════════════════════════
function initLogin(form) {
  // If already logged in, bounce to home
  if (API.isLoggedIn()) {
    window.location.href = '/';
    return;
  }

  const submitBtn = form.querySelector('button[type="submit"]');
  const emailInput = form.querySelector('#login-email');
  const passwordInput = form.querySelector('#login-password');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(form);

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    // Client‑side validation
    if (!email) return showFieldError(emailInput, 'Email is required');
    if (!isValidEmail(email)) return showFieldError(emailInput, 'Enter a valid email');
    if (!password) return showFieldError(passwordInput, 'Password is required');

    setLoading(submitBtn, true);

    try {
      const data = await API.post('/api/auth/login', { email, password });
      API.setAuth(data);
      Toast.success('Welcome back to Lumière!');
      setTimeout(() => {
        window.location.href = '/';
      }, 600);
    } catch (err) {
      Toast.error(err.message || 'Login failed');
      shakeElement(form);
    } finally {
      setLoading(submitBtn, false);
    }
  });

  // Password visibility toggle
  initPasswordToggle(form);
}


// ═════════════════════════════════════════════════════════════
// REGISTER
// ═════════════════════════════════════════════════════════════
function initRegister(form) {
  if (API.isLoggedIn()) {
    window.location.href = '/';
    return;
  }

  const submitBtn = form.querySelector('button[type="submit"]');
  const nameInput = form.querySelector('#register-name');
  const emailInput = form.querySelector('#register-email');
  const passwordInput = form.querySelector('#register-password');
  const confirmInput = form.querySelector('#register-confirm');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(form);

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const confirm = confirmInput.value;

    // Validation
    if (!name) return showFieldError(nameInput, 'Name is required');
    if (name.length < 2) return showFieldError(nameInput, 'Name must be at least 2 characters');
    if (!email) return showFieldError(emailInput, 'Email is required');
    if (!isValidEmail(email)) return showFieldError(emailInput, 'Enter a valid email');
    if (!password) return showFieldError(passwordInput, 'Password is required');
    if (password.length < 6) return showFieldError(passwordInput, 'Password must be at least 6 characters');
    if (password !== confirm) return showFieldError(confirmInput, 'Passwords do not match');

    setLoading(submitBtn, true);

    try {
      const data = await API.post('/api/auth/register', { name, email, password });
      API.setAuth(data);
      Toast.success('Welcome to Lumière! Your account is ready.');
      setTimeout(() => {
        window.location.href = '/';
      }, 600);
    } catch (err) {
      Toast.error(err.message || 'Registration failed');
      shakeElement(form);
    } finally {
      setLoading(submitBtn, false);
    }
  });

  // Real‑time password match indicator
  if (confirmInput && passwordInput) {
    confirmInput.addEventListener('input', () => {
      if (confirmInput.value && confirmInput.value !== passwordInput.value) {
        confirmInput.classList.add('input-error');
      } else {
        confirmInput.classList.remove('input-error');
      }
    });
  }

  initPasswordToggle(form);
}


// ═════════════════════════════════════════════════════════════
// PROFILE
// ═════════════════════════════════════════════════════════════
function initProfile(form) {
  if (!requireAuth()) return;

  const submitBtn = form.querySelector('button[type="submit"]');
  const nameInput = form.querySelector('#profile-name');
  const emailInput = form.querySelector('#profile-email');
  const historyContainer = document.getElementById('recommendation-history');
  const avatarEl = document.getElementById('profile-avatar');

  // ── Load profile data ──
  loadProfile();

  async function loadProfile() {
    try {
      const data = await API.get('/api/auth/profile');

      if (nameInput) nameInput.value = data.name || '';
      if (emailInput) emailInput.value = data.email || '';

      // Set avatar initial
      if (avatarEl && data.name) {
        avatarEl.textContent = data.name.charAt(0).toUpperCase();
      }

      // Populate extra fields if they exist
      const phoneInput = form.querySelector('#profile-phone');
      if (phoneInput && data.phone) phoneInput.value = data.phone;

    } catch (err) {
      Toast.error('Failed to load profile');
      console.error(err);
    }
  }

  // ── Update profile ──
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(form);

    const name = nameInput ? nameInput.value.trim() : '';
    const email = emailInput ? emailInput.value.trim() : '';

    if (!name) return showFieldError(nameInput, 'Name is required');
    if (!email || !isValidEmail(email)) return showFieldError(emailInput, 'Valid email required');

    setLoading(submitBtn, true);

    try {
      const payload = { name, email };

      // Include optional fields
      const phoneInput = form.querySelector('#profile-phone');
      if (phoneInput) payload.phone = phoneInput.value.trim();

      const data = await API.put('/api/auth/profile', payload);

      // Update local storage with fresh data
      const current = API.getUser();
      if (current) {
        API.setAuth({ ...current, ...data, token: current.token });
      }

      Toast.success('Profile updated successfully');
    } catch (err) {
      Toast.error(err.message || 'Failed to update profile');
    } finally {
      setLoading(submitBtn, false);
    }
  });

  // ── Load recommendation history ──
  if (historyContainer) {
    loadHistory(historyContainer);
  }
}

async function loadHistory(container) {
  container.innerHTML = `
    <div class="loading-skeleton">
      <div class="skeleton-line"></div>
      <div class="skeleton-line skeleton-short"></div>
      <div class="skeleton-line"></div>
    </div>
  `;

  try {
    const data = await API.get('/api/recommendations/history');
    const history = data.history || data || [];

    if (!history.length) {
      container.innerHTML = `
        <div class="empty-state-mini">
          <p>No recommendation history yet.</p>
          <a href="/preferences.html" class="btn-primary">Get Recommendations</a>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <ul class="history-list">
        ${history
          .map(
            (item, i) => `
          <li class="history-item animate-fadeInUp" style="animation-delay: ${i * 0.05}s">
            <div class="history-item-header">
              <span class="history-date">${formatDate(item.createdAt || item.date)}</span>
              <span class="history-count">${item.results?.length || item.count || 0} results</span>
            </div>
            <div class="history-tags">
              ${item.preferences ? Object.entries(item.preferences)
                .filter(([_, v]) => v)
                .map(([k, v]) => `<span class="tag">${v}</span>`)
                .join('') : ''}
            </div>
          </li>
        `
          )
          .join('')}
      </ul>
    `;
  } catch (err) {
    container.innerHTML = `
      <div class="empty-state-mini">
        <p>Could not load history.</p>
      </div>
    `;
    console.error(err);
  }
}


// ═════════════════════════════════════════════════════════════
// UTILITIES
// ═════════════════════════════════════════════════════════════

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showFieldError(input, message) {
  if (!input) return;
  input.classList.add('input-error');

  // Remove existing error message
  const existing = input.parentElement.querySelector('.field-error');
  if (existing) existing.remove();

  const errEl = document.createElement('span');
  errEl.className = 'field-error';
  errEl.textContent = message;
  input.parentElement.appendChild(errEl);
  input.focus();
}

function clearErrors(form) {
  form.querySelectorAll('.input-error').forEach((el) => el.classList.remove('input-error'));
  form.querySelectorAll('.field-error').forEach((el) => el.remove());
}

function setLoading(button, loading) {
  if (!button) return;
  if (loading) {
    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.innerHTML = `<span class="btn-spinner"></span> Please wait...`;
    button.classList.add('btn-loading');
  } else {
    button.disabled = false;
    button.textContent = button.dataset.originalText || 'Submit';
    button.classList.remove('btn-loading');
  }
}

function shakeElement(el) {
  el.classList.add('shake');
  setTimeout(() => el.classList.remove('shake'), 600);
}

function initPasswordToggle(form) {
  form.querySelectorAll('.password-toggle').forEach((toggle) => {
    toggle.addEventListener('click', () => {
      const input = toggle.previousElementSibling || toggle.parentElement.querySelector('input');
      if (!input) return;
      const isPassword = input.type === 'password';
      input.type = isPassword ? 'text' : 'password';
      toggle.textContent = isPassword ? '🙈' : '👁️';
    });
  });
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}
