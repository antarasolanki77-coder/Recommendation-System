/* ============================================================
   Lumière — Saved Recommendations Page
   View, search, filter & manage saved jewelry items
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // ── Auth gate ──────────────────────────────────────────────
  if (!requireAuth()) return;

  // ── DOM References ─────────────────────────────────────────
  const savedGrid = document.getElementById('saved-grid');
  const emptyState = document.getElementById('empty-state');
  const searchInput = document.getElementById('saved-search');
  const categoryFilter = document.getElementById('category-filter');
  const savedCount = document.getElementById('saved-count');
  const sortSelect = document.getElementById('saved-sort');

  // ── State ──────────────────────────────────────────────────
  let allItems = [];
  let filteredItems = [];

  // ── Initialise ─────────────────────────────────────────────
  loadSavedItems();

  // ── Bind filters ───────────────────────────────────────────
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => applyFilters(), 250);
    });
  }

  if (categoryFilter) {
    categoryFilter.addEventListener('change', () => applyFilters());
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', () => applyFilters());
  }


  // ═════════════════════════════════════════════════════════════
  // LOAD SAVED ITEMS
  // ═════════════════════════════════════════════════════════════
  async function loadSavedItems() {
    showLoadingSkeleton();

    try {
      const data = await API.get('/api/saved');
      allItems = data.saved || data.items || data || [];

      if (!Array.isArray(allItems)) allItems = [];

      populateCategoryFilter(allItems);
      applyFilters();
    } catch (err) {
      Toast.error('Failed to load saved items');
      console.error(err);
      showEmptyState();
    }
  }


  // ═════════════════════════════════════════════════════════════
  // FILTERS & SORTING
  // ═════════════════════════════════════════════════════════════
  function applyFilters() {
    const searchTerm = searchInput ? searchInput.value.trim().toLowerCase() : '';
    const category = categoryFilter ? categoryFilter.value : '';
    const sortBy = sortSelect ? sortSelect.value : '';

    // Filter
    filteredItems = allItems.filter((item) => {
      const matchesSearch =
        !searchTerm ||
        (item.title || '').toLowerCase().includes(searchTerm) ||
        (item.category || '').toLowerCase().includes(searchTerm) ||
        (item.metal || '').toLowerCase().includes(searchTerm) ||
        (item.style || '').toLowerCase().includes(searchTerm);

      const matchesCategory = !category || (item.category || '').toLowerCase() === category.toLowerCase();

      return matchesSearch && matchesCategory;
    });

    // Sort
    if (sortBy === 'price-asc') {
      filteredItems.sort((a, b) => (a.price || 0) - (b.price || 0));
    } else if (sortBy === 'price-desc') {
      filteredItems.sort((a, b) => (b.price || 0) - (a.price || 0));
    } else if (sortBy === 'name') {
      filteredItems.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
    } else if (sortBy === 'match') {
      filteredItems.sort((a, b) => (b.matchPercent || 0) - (a.matchPercent || 0));
    }
    // Default: newest first (order from API)

    renderItems(filteredItems);
  }

  function populateCategoryFilter(items) {
    if (!categoryFilter) return;

    const categories = [...new Set(items.map((i) => i.category).filter(Boolean))];

    categoryFilter.innerHTML =
      '<option value="">All Categories</option>' +
      categories.map((c) => `<option value="${c}">${c}</option>`).join('');
  }


  // ═════════════════════════════════════════════════════════════
  // RENDER
  // ═════════════════════════════════════════════════════════════
  function renderItems(items) {
    if (!savedGrid) return;

    // Update count
    if (savedCount) {
      savedCount.textContent = `${items.length} saved item${items.length !== 1 ? 's' : ''}`;
    }

    // Show/hide empty state
    if (items.length === 0) {
      showEmptyState();
      savedGrid.innerHTML = '';
      return;
    }

    hideEmptyState();

    savedGrid.innerHTML = items
      .map(
        (item, i) => `
      <div class="saved-card animate-fadeInUp" style="animation-delay: ${i * 0.08}s" data-id="${item._id || ''}">
        <div class="saved-card-image">
          <img
            src="${item.image || ''}"
            alt="${escapeHtml(item.title || 'Jewelry')}"
            loading="lazy"
            onerror="this.src='https://images.unsplash.com/photo-1515562141589-67f0d569b3b3?w=400&h=400&fit=crop'"
          >
          ${
            item.matchPercent
              ? `
            <div class="match-badge ${getMatchClass(item.matchPercent)}">
              <span class="match-text">${item.matchPercent}%</span>
            </div>
          `
              : ''
          }
        </div>
        <div class="saved-card-body">
          <h3 class="saved-title">${escapeHtml(item.title || 'Untitled')}</h3>
          <p class="saved-price">₹${formatPrice(item.price)}</p>
          <p class="saved-meta">
            ${escapeHtml(item.category || '')}${item.metal ? ' · ' + escapeHtml(item.metal) : ''}${item.style ? ' · ' + escapeHtml(item.style) : ''}
          </p>
          ${
            item.reasons && item.reasons.length
              ? `
            <div class="saved-reasons">
              ${item.reasons.map((r) => `<span class="reason-tag">${escapeHtml(r)}</span>`).join('')}
            </div>
          `
              : ''
          }
          <div class="saved-card-actions">
            <button class="btn-outline remove-btn" data-id="${item._id || ''}" title="Remove from saved">
              <span class="remove-icon">✕</span> Remove
            </button>
          </div>
        </div>
      </div>
    `
      )
      .join('');

    // Bind remove buttons
    savedGrid.querySelectorAll('.remove-btn').forEach((btn) => {
      btn.addEventListener('click', () => handleRemove(btn));
    });
  }


  // ═════════════════════════════════════════════════════════════
  // REMOVE SAVED ITEM
  // ═════════════════════════════════════════════════════════════
  async function handleRemove(btn) {
    const id = btn.dataset.id;
    if (!id) return;

    const card = btn.closest('.saved-card');

    // Confirm with visual feedback
    if (btn.dataset.confirming === 'true') {
      // Second click → proceed
      btn.disabled = true;

      try {
        await API.delete(`/api/saved/${id}`);

        // Animate out
        if (card) {
          card.style.transition = 'all 0.4s ease';
          card.style.opacity = '0';
          card.style.transform = 'scale(0.8) translateY(20px)';

          setTimeout(() => {
            card.remove();

            // Remove from local state
            allItems = allItems.filter((item) => item._id !== id);
            filteredItems = filteredItems.filter((item) => item._id !== id);

            // Update count
            if (savedCount) {
              savedCount.textContent = `${filteredItems.length} saved item${filteredItems.length !== 1 ? 's' : ''}`;
            }

            // Show empty state if needed
            if (allItems.length === 0) showEmptyState();
          }, 400);
        }

        Toast.success('Removed from your collection');
      } catch (err) {
        Toast.error(err.message || 'Failed to remove');
        btn.disabled = false;
      }
    } else {
      // First click → confirm
      btn.dataset.confirming = 'true';
      btn.innerHTML = '<span class="remove-icon">⚠</span> Confirm?';
      btn.classList.add('btn-danger');

      // Reset after 3 seconds if no second click
      setTimeout(() => {
        if (btn.dataset.confirming === 'true') {
          btn.dataset.confirming = 'false';
          btn.innerHTML = '<span class="remove-icon">✕</span> Remove';
          btn.classList.remove('btn-danger');
        }
      }, 3000);
    }
  }


  // ═════════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═════════════════════════════════════════════════════════════
  function showEmptyState() {
    if (emptyState) {
      emptyState.style.display = 'flex';
      emptyState.innerHTML = `
        <div class="empty-content">
          <div class="empty-icon">💎</div>
          <h3>No saved items yet</h3>
          <p>Discover and save your favourite jewelry recommendations.</p>
          <a href="/preferences.html" class="btn-primary">Get Recommendations</a>
        </div>
      `;
    }
  }

  function hideEmptyState() {
    if (emptyState) {
      emptyState.style.display = 'none';
    }
  }


  // ═════════════════════════════════════════════════════════════
  // LOADING SKELETON
  // ═════════════════════════════════════════════════════════════
  function showLoadingSkeleton() {
    if (!savedGrid) return;

    savedGrid.innerHTML = Array.from({ length: 6 })
      .map(
        () => `
      <div class="saved-card skeleton-card">
        <div class="skeleton-image"></div>
        <div class="saved-card-body">
          <div class="skeleton-line skeleton-title"></div>
          <div class="skeleton-line skeleton-short"></div>
          <div class="skeleton-line"></div>
        </div>
      </div>
    `
      )
      .join('');
  }


  // ═════════════════════════════════════════════════════════════
  // UTILITIES
  // ═════════════════════════════════════════════════════════════
  function getMatchClass(percent) {
    if (percent >= 80) return 'high';
    if (percent >= 60) return 'medium';
    return 'low';
  }

  function formatPrice(price) {
    if (!price && price !== 0) return '—';
    return Number(price).toLocaleString('en-IN');
  }

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
});
